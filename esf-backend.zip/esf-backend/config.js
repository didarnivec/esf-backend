module.exports = {
  wsdl: {
    session: 'https://esf.gov.kz:8443/esf-web/ws/api1/SessionService?wsdl',
    invoice: 'https://esf.gov.kz:8443/esf-web/ws/api1/InvoiceService?wsdl',
  },
}
